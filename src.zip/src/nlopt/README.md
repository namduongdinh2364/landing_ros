nlopt
=====

This package integrates NL opt with Catkin
