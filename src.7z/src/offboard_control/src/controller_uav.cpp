#include "offboard_control/controller_uav.h"

using namespace Eigen;
using namespace std;

#define PRO_ON_MEAN			1
#define PRO_ON_ERROR		0

Eigen::Vector3d toEigen(const geometry_msgs::Point &p) {
	Eigen::Vector3d ev3(p.x, p.y, p.z);
	return ev3;
}

inline Eigen::Vector3d toEigen(const geometry_msgs::Vector3 &v3) {
	Eigen::Vector3d ev3(v3.x, v3.y, v3.z);
	return ev3;
}


velocityCtrl::velocityCtrl(const ros::NodeHandle &nh, const ros::NodeHandle &nh_private)
		: nh_(nh), nh_private_(nh_private), node_state(WAITING_FOR_HOME_POSE), flight_mode(POSITION_MODE), sim_enable_(true)

{
	mavposeSub_ = nh_.subscribe("mavros/local_position/pose", 1, &velocityCtrl::mavposeCallback, this, ros::TransportHints().tcpNoDelay());

	cmdloop_timer_ = nh_.createTimer(ros::Duration(0.01), &velocityCtrl::cmdloopCallback,this);  // Define timer for constant loop rate

	setRaw_pub = nh_.advertise<mavros_msgs::PositionTarget>("/mavros/setpoint_raw/local",10);

	target_pose = nh_.subscribe("/target_pos", 10, &velocityCtrl::targetPositioncallback, this, ros::TransportHints().tcpNoDelay());

	setpoint_pose_pub_ = nh_.advertise<geometry_msgs::PoseStamped>("mavros/setpoint_position/local", 10);

	statusloop_timer_ = nh_.createTimer(ros::Duration(1), &velocityCtrl::statusloopCallback, this);

	land_service_ = nh_.advertiseService("land", &velocityCtrl::landCallback, this);

	velocity_pub_   = nh_.advertise <geometry_msgs::TwistStamped>("/mavros/setpoint_velocity/cmd_vel", 10 );

	nh_private_.param<double>("init_pos_x", initTargetPos_x_, 0.0);
	nh_private_.param<double>("init_pos_y", initTargetPos_y_, 0.0);
	nh_private_.param<double>("init_pos_z", initTargetPos_z_, 1.0);

	nh_private_.param<double>("Kp_x", kpx_, 0.5);
	nh_private_.param<double>("Kd_x", kdx_, 0.5);
	nh_private_.param<double>("Ki_x", kix_, 0.0);

	nh_private_.param<double>("Kp_y", kpy_, 0.5);
	nh_private_.param<double>("Kd_y", kdy_, 0.5);
	nh_private_.param<double>("Ki_y", kiy_, 0.0);

	nh_private_.param<double>("Kp_z", kpz_, 0.5);
	nh_private_.param<double>("Kd_z", kdz_, 0.5);
	nh_private_.param<double>("Ki_z", kiz_, 1.0);

	nh_private_.param<double>("kp_yaw_", kpyaw_, 0.5);
	nh_private_.param<double>("kd_yaw_", kdyaw_, 0.5);
	nh_private_.param<double>("ki_yaw_", kiyaw_, 0.0);

	nh_private_.param<double>("max_out", max_out_, 1.5);
	nh_private_.param<double>("min_out", min_out_, -1.5);

	targetPos_ << initTargetPos_x_, initTargetPos_y_, initTargetPos_z_;




	PID_x.setKp(kpx_);
	PID_x.setKd(kdx_);
	PID_x.setKi(kix_);
	PID_x.setUMax(0.5);
	PID_x.setUMin(min_out_);
	PID_x.SetMode(PRO_ON_MEAN);


	PID_y.setKp(kpy_);
	PID_y.setKd(kdy_);
	PID_y.setKi(kiy_);
	PID_y.setUMax(0.5);
	PID_y.setUMin(min_out_);
	PID_y.SetMode(PRO_ON_MEAN);

	PID_z.setKp(kpz_);
	PID_z.setKd(kdz_);
	PID_z.setKi(kiz_);
	PID_z.setUMax(max_out_);
	PID_z.setUMin(min_out_);
	PID_z.SetMode(PRO_ON_MEAN);

	PID_yaw.setKp(kpyaw_);
	PID_yaw.setKi(kiyaw_);
	PID_yaw.setKd(kdyaw_);
	PID_yaw.setUMax(max_out_);
	PID_yaw.setUMin(min_out_);
	PID_yaw.SetMode(PRO_ON_MEAN);

	error = 0.1;
}

void velocityCtrl::targetPositioncallback(const geometry_msgs::PoseStamped &msg){

	targetPos_ = toEigen(msg.pose.position);
}
void velocityCtrl::mavposeCallback(const geometry_msgs::PoseStamped &msg) {

		if (!received_home_pose)
		{
			received_home_pose = true;
			home_pose_ = msg.pose;
			ROS_INFO_STREAM("Home pose initialized to: " << home_pose_);
		}

		mavPos_ = toEigen(msg.pose.position);

		mavAtt_(0) = msg.pose.orientation.w;
		mavAtt_(1) = msg.pose.orientation.x;
		mavAtt_(2) = msg.pose.orientation.y;
		mavAtt_(3) = msg.pose.orientation.z;
}

void velocityCtrl::mavtwistCallback(const geometry_msgs::TwistStamped &msg) {

		mavVel_ = toEigen(msg.twist.linear);
		mavRate_ = toEigen(msg.twist.angular);
}


void velocityCtrl::statusloopCallback(const ros::TimerEvent &event) {
	if (sim_enable_) {
		// Enable OFFBoard mode and arm automatically
		// This is only run if the vehicle is simulated
		arm_cmd_.request.value = true;
		offb_set_mode_.request.custom_mode = "OFFBOARD";

		if (current_state_.mode != "OFFBOARD" && (ros::Time::now() - last_request_ > ros::Duration(5.0))) {

			if (set_mode_client_.call(offb_set_mode_) && offb_set_mode_.response.mode_sent) {

				ROS_INFO("Offboard enabled");
			}

			last_request_ = ros::Time::now();
		}
		else {
			if (!current_state_.armed && (ros::Time::now() - last_request_ > ros::Duration(5.0))) {

				if (arming_client_.call(arm_cmd_) && arm_cmd_.response.success) {
					ROS_INFO("Vehicle armed");
				}

				last_request_ = ros::Time::now();
			}
		}

	}

	if(mavPos_(2) > 15.0){
		node_state = LANDING;
	}

}

bool velocityCtrl::landCallback(std_srvs::SetBool::Request &request, std_srvs::SetBool::Response &response) {

	node_state = LANDING;
	ROS_WARN("Dinh Lam");
	return true;
}

bool velocityCtrl::check_position(float error, Eigen::Vector3d current, Eigen::Vector3d target){

	Eigen::Vector3d stop;
	stop << target - current;
	double a = stop.norm();

	if (a <= error){

		cout << "Reach target!" << endl;
		cout << a << endl;

		return true;
	}
	else
		return false;
}

void velocityCtrl::cmdloopCallback(const ros::TimerEvent &event)
{
	switch (node_state) {
		case WAITING_FOR_HOME_POSE:
		{
			waitForPredicate(&received_home_pose, "Waiting for home pose...");
			ROS_INFO("Got pose! Drone Ready to be armed.");
			node_state = MISSION_EXECUTION;

			break;
		}

		case MISSION_EXECUTION:
		{
			switch (flight_mode)
		{
				case POSITION_MODE:
				{
					if(check_position(error, mavPos_, targetPos_))
					{
						flight_mode = VELOCITY_MODE;
					}

					pubPosition(targetPos_);

					break;
				}
				case VELOCITY_MODE:
				{
					// ROS_INFO("Got pose! Drone Velocity mode");
					Eigen::Vector3d velocity_vector;


					velocity_vector(0) = PID_x.compute(targetPos_(0), mavPos_(0));
					velocity_vector(1) = PID_y.compute(targetPos_(1), mavPos_(1));
					velocity_vector(2) = PID_z.compute(targetPos_(2), mavPos_(2));

					ROS_INFO_STREAM("Got pose! Drone Velocity x " << velocity_vector(0) << " y " << velocity_vector(1) << " z " << velocity_vector(2));

					pubVelocity(velocity_vector);

					break;
				}

			}
			break;
		}

		case LANDING:
		{
			offb_set_mode_.request.custom_mode = "AUTO.LAND";

			if( set_mode_client_.call(offb_set_mode_) && offb_set_mode_.response.mode_sent)
			{
				ROS_INFO("[ INFO] --------------- LAND ---------------\n");
			}
			node_state = LANDED;

			ros::spinOnce();

			break;
		}

		case LANDED:
		{
			ROS_INFO("Landed. Please set to position control and disarm.");
			cmdloop_timer_.stop();

			break;
		}
	}
}

void velocityCtrl::pubPosition(const Eigen::Vector3d &target_position){
	geometry_msgs::PoseStamped target_pose_;

	target_pose_.header.stamp = ros::Time::now();

	target_pose_.pose.position.x = target_position(0);
	target_pose_.pose.position.y = target_position(1);
	target_pose_.pose.position.z = target_position(2);

	target_pose_.pose.orientation.w = 1.0;
	target_pose_.pose.orientation.x = 0.0;
	target_pose_.pose.orientation.y = 0.0;
	target_pose_.pose.orientation.z = 0.0;

	setpoint_pose_pub_.publish(target_pose_);
}

void velocityCtrl::pubVelocity(const Eigen::Vector3d &desire_velicity_){

	mavros_msgs::PositionTarget setpoint_local;

	setpoint_local.coordinate_frame = mavros_msgs::PositionTarget::FRAME_BODY_NED;

	setpoint_local.type_mask = 1987;

	setpoint_local.velocity.x = desire_velicity_(0);
	setpoint_local.velocity.y = desire_velicity_(1);
	setpoint_local.velocity.z = desire_velicity_(2);

	setRaw_pub.publish(setpoint_local);
}

void velocityCtrl::dynamicReconfigureCallback(velocity_controller::VelocityControllerConfig &config, uint32_t level) {

	if (PID_x.getKp() != config.kpx) {
		PID_x.setKp(config.kpx);
		ROS_INFO("Reconfigure request : kpx_ = %.2f ", config.kpx);
	}
	else if (PID_x.getKi() != config.kix) {
		PID_x.setKi(config.kix);
		ROS_INFO("Reconfigure request : kix_ = %.2f ", config.kix);
	}
	else if (PID_x.getKd() != config.kdx) {
		PID_x.setKd(config.kdx);
		ROS_INFO("Reconfigure request : kdx_ = %.2f ", config.kdx);
	}

	else if (PID_y.getKp() != config.kpy) {
		PID_y.setKp(config.kpy);
		ROS_INFO("Reconfigure request : kpy_ = %.2f ", config.kpy);
	}
	else if (PID_y.getKi() != config.kiy) {
		PID_y.setKi(config.kiy);
		ROS_INFO("Reconfigure request : kiy_ = %.2f ", config.kiy);
	}
	else if (PID_y.getKd() != config.kdy) {
		PID_y.setKd(config.kdy);
		ROS_INFO("Reconfigure request : kdy_ = %.2f ", config.kdy);
	}

	else if (PID_z.getKp() != config.kpz) {
		PID_z.setKp(config.kpz);
		ROS_INFO("Reconfigure request : kpz_ = %.2f ", config.kpz);
	}
	else if (PID_z.getKi() != config.kiz) {
		PID_z.setKi(config.kiz);
		ROS_INFO("Reconfigure request : kiz_ = %.2f ", config.kiz);
	}
	else if (PID_z.getKd() != config.kdz) {
		PID_z.setKd(config.kdz);
		ROS_INFO("Reconfigure request : kdz_ = %.2f ", config.kdz);
	}

	else if (PID_yaw.getKp() != config.kp_yaw) {
		PID_yaw.setKp(config.kp_yaw);
		ROS_INFO("Reconfigure request : kpyaw_ = %.2f ", config.kp_yaw);
	}
	else if (PID_yaw.getKi() != config.ki_yaw) {
		PID_yaw.setKi(config.ki_yaw);
		ROS_INFO("Reconfigure request : kiyaw_ = %.2f ", config.ki_yaw);
	}
	else if (PID_yaw.getKd() != config.kd_yaw) {
		PID_yaw.setKd(config.kd_yaw);
		ROS_INFO("Reconfigure request : kdyaw_ = %.2f ", config.kd_yaw);
	}

	else if (PID_yaw.getUMax() != config.UMax_yaw) {
		PID_yaw.setUMax(config.UMax_yaw);
		ROS_INFO("Reconfigure request : UMax_yaw = %.2f ", config.UMax_yaw);
	}
	else if (PID_yaw.getUMin() != config.UMin_yaw) {
		PID_yaw.setUMin(config.UMin_yaw);
		ROS_INFO("Reconfigure request : UMin = %.2f ", config.UMin_yaw);
	}

	else if (PID_x.getUMax() != config.UMax_x) {
		PID_x.setUMax(config.UMax_x);
		ROS_INFO("Reconfigure request : UMax_x = %.2f ", config.UMax_x);
	}
	else if (PID_x.getUMin() != config.UMin_x) {
		PID_x.setUMin(config.UMin_x);
		ROS_INFO("Reconfigure request : UMin_x = %.2f ", config.UMin_x);
	}

	else if (PID_y.getUMax() != config.UMax_y) {
		PID_y.setUMax(config.UMax_y);
		ROS_INFO("Reconfigure request : UMax_y = %.2f ", config.UMax_y);
	}
	else if (PID_y.getUMin() != config.UMin_y) {
		PID_y.setUMin(config.UMin_y);
		ROS_INFO("Reconfigure request : UMin_y = %.2f ", config.UMin_y);
	}

	else if (PID_z.getUMax() != config.UMax_z) {
		PID_yaw.setUMax(config.UMax_z);
		ROS_INFO("Reconfigure request : UMax_z = %.2f ", config.UMax_z);
	}

	else if (PID_z.getUMin() != config.UMin_z) {
		PID_z.setUMin(config.UMin_z);
		ROS_INFO("Reconfigure request : UMin_z = %.2f ", config.UMin_z);
	}
}


