#include "offboard_control/pid_controller_base.h"

PidControllerBase::PidControllerBase()
	: kp_(0.0),
		ki_(0.0),
		kd_(0.0),
		ui_old_(0.0),
		error_old_(0.0),
		u_max_(std::numeric_limits<double>::infinity()),
		u_min_(-std::numeric_limits<double>::infinity())
{

}

PidControllerBase::PidControllerBase(double kp, double ki, double kd)
	: kp_(kp),
		ki_(ki),
		kd_(kd),
		ui_old_(0.0),
		error_old_(0.0),
		u_max_(std::numeric_limits<double>::infinity()),
		u_min_(-std::numeric_limits<double>::infinity())
{
	// kp_ = kp;
	// ki_ = ki;
	// kd_ = kd;
}

PidControllerBase::PidControllerBase(double kp, double ki, double kd,
									bool proportional_on_measurement, bool differetial_on_measurement)
	: kp_(kp),
		ki_(ki),
		kd_(kd),
		ui_old_(0.0),
		error_old_(0.0),
		proportional_on_measurement_(true),
		differetial_on_measurement_(true),
		u_max_(std::numeric_limits<double>::infinity()),
		u_min_(-std::numeric_limits<double>::infinity())
{
	// kp_ = kp;
	// ki_ = ki;
	// kd_ = kd;
}


PidControllerBase::~PidControllerBase()
{

};

double PidControllerBase::getKp(void)
{
	return kp_;
}

void PidControllerBase::SetMode(double mode)
{
	proportional_on_measurement_ = mode;
}

double PidControllerBase::getKi(void)
{
	return ki_;
}

double PidControllerBase::getKd(void)
{
	return kd_;
}

double PidControllerBase::getUMax(void)
{
		return u_max_;
}

double PidControllerBase::getUMin(void)
{
	return u_min_;
}

void PidControllerBase::setKp(double kp)
{
	kp_ = kp;
}

void PidControllerBase::setKi(double ki)
{
	ki_ = ki;
}

void PidControllerBase::setKd(double kd)
{
	kd_ = kd;
}

void PidControllerBase::setUMax(double u_max)
{
	u_max_ = u_max;
}

void PidControllerBase::setUMin(double u_min)
{
	u_min_ = u_min;
}

double PidControllerBase:: compute(double ref, double meas)
{

	double dt;
	double u, ud, error;
	double dMeas;

	/* variables proportional-on-error */
	double Pout, Iout, Dout;
	double derivative;

	if (!lastTime.isZero()) {

		dt = (ros::Time::now() - lastTime).toSec();

		if (0 == dt)
		{
			return last_u;
		}

	} else {

		ROS_INFO("lastTime is 0, doing nothing");
		lastTime = ros::Time::now();

		return last_u;
	}

	if (sample_time > dt)
	{
		return last_u;
	}


	error = ref - meas;

	dMeas = meas - last_meas;

	// derivative term
	if (proportional_on_measurement_) {

		up -= kp_*dMeas;
		// integral term
		// saturation and anti-wind up
		ui += ki_*(error*dt);
		ud = -kd_ * dMeas / dt;

		ui = clamp(ui, u_max_, u_min_);

		// total = p + i + d
		u = up + ui + ud;

		std::cout << "testtttt "<< std::endl;
	}
	else
	{
		Pout = kp_ * error;

		integral += (1/2 * (error * dt));
		Iout = ki_ * integral;

		derivative = (error - error_old_) / dt;
		Dout = kd_ * derivative;

		u = Pout + Iout + Dout;
	}


	u = clamp(u, u_max_, u_min_);

	last_meas = meas;
	last_u = u;

	error_old_ = error;
	lastTime = ros::Time::now();

	return u;
}

double PidControllerBase::clamp(double value, double u_max, double u_min){
	if (value > u_max)
	{
		return u_max;
	}
	else if (value < u_min)
	{
		return u_min;
	}
	else
	{
		return value;
	}
}
