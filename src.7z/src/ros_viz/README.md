# terminal 1
```bash
roslaunch ros_viz visualize.launch
```
# terminal 2
```bash
rosbag play --pause name.bag
```
